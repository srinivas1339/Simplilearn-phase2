import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { StartComponent } from './start/start.component';
import { TestPageComponent } from './test-page/test-page.component';
import { FinishComponent } from './finish/finish.component';

const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"start",component:StartComponent},
  {path:"test-page/:questionNumber",component: TestPageComponent },
  {path:"finish/:totalScore",component:FinishComponent},
  {path:"",redirectTo:"/login",pathMatch:"full"},
  {path:"**",redirectTo:"/login"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
