import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {
userName:string;
lastName:string;
  constructor() { 
    this.userName="srinu";
    this.lastName="yeldi";
  }

  ngOnInit(): void {  }
  inputEventHandler(e)
  {
    this.userName=e.target.value; 
  }

}
