import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {Questions} from '../questions';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-test-page',
  templateUrl: './test-page.component.html',
  styleUrls: ['./test-page.component.css']
})
export class TestPageComponent implements OnInit {
  currentQuestionNumber:number;
  selectedAnswer:number;
  checkedFlag:boolean;
  currentRadioSelected:number;
  numberOfCorrectAns:number;
  questionArray:Questions[]=new Array();
  constructor(public activatedRoute:ActivatedRoute,public router:Router) {
    this.questionArray.push(new Questions(1,"Grand Central Terminal, Park Avenue, New York is the world's","largest railway station","highest railway station","longest railway station","None of the above",1));
    this.questionArray.push(new Questions(2,"Entomology is the science that studies","Behavior of human beings","	Insects","	The origin and history of technical and scientific terms","The formation of rocks",2));
    this.questionArray.push(new Questions(3,"Eritrea, which became the 182nd member of the UN in 1993, is in the continent of","Asia","Africa","Europe","Australia",2));
    this.questionArray.push(new Questions(4,"For which of the following disciplines is Nobel Prize awarded?","Physics and Chemistry","Physiology or Medicine","Literature, Peace and Economics","All of the above",4));
    this.questionArray.push(new Questions(5,"Hitler party which came into power in 1933 is known as","Labour Party","Nazi Party","Ku-Klux-Klan","	Democratic Party",2));
    this.questionArray.push(new Questions(6,"FFC stands for","Foreign Finance Corporation","	Film Finance Corporation","Federation of Football Council","None of the above",2));
    this.questionArray.push(new Questions(7,"Fastest shorthand writer was","Dr. G. D. Bist","J.R.D. Tata","J.M. Tagore","	Khudada Khan",1));
    this.questionArray.push(new Questions(8,"Epsom (England) is the place associated with","Horse racing","Polo","Shooting","Snooker",1));
    this.questionArray.push(new Questions(9,"Galileo was an Italian astronomer who","developed the telescope","discovered four satellites of Jupiter","	discovered that the movement of pendulum produces a regular time measurement","All of the above",4));
    this.questionArray.push(new Questions(10,"First human heart transplant operation conducted by Dr. Christiaan Barnard on Louis Washkansky, was conducted in","1967","1968","1958","1922",1));
    this.questionArray.push(new Questions(11,"Habeas Corpus Act 1679","states that no one was to be imprisoned without a writ or warrant stating the charge against him","provided facilities to a prisoner to obtain either speedy trial or release in bail","safeguarded the personal liberties of the people against arbitrary imprisonment by the king's orders","All of the above",4));
    this.questionArray.push(new Questions(12,"Exposure to sunlight helps a person improve his health because","the infrared light kills bacteria in the body","resistance power increases","the pigment cells in the skin get stimulated and produce a healthy tan","the ultraviolet rays convert skin oil into Vitamin D",4));
    this.questionArray.push(new Questions(13,"Golf player Vijay Singh belongs to which country?","USA","Fiji","India","UK",2));
    this.questionArray.push(new Questions(14,"Guarantee to an exporter that the importer of his goods will pay immediately for the goods ordered by him, is known as","Letter of Credit (L/C)","laissezfaire","inflation","None of the above",1));
    this.questionArray.push(new Questions(15,"First Afghan War took place in","1839","1843","1833","1848",1));
   
    this.selectedAnswer=-1;
    this.checkedFlag=false;
    this.currentRadioSelected=-1;
    this.numberOfCorrectAns=0;
   }

  ngOnInit(): void {
    this.currentQuestionNumber=parseInt(this.activatedRoute.snapshot.params["questionNumber"]);
  }
  nextQuestionEventHandler()
  {
    this.currentQuestionNumber=parseInt(this.activatedRoute.snapshot.params["questionNumber"]);
    this.currentQuestionNumber++;
    this.selectedAnswer=-1;
    this.checkedFlag=false;
    this.currentRadioSelected=-1;
    this.router.navigateByUrl("/test-page/"+(this.currentQuestionNumber));
  }
  finishQuestionEventHandler()
  {
    console.log(this.numberOfCorrectAns);
   this.router.navigateByUrl("/finish/" + (this.numberOfCorrectAns));
   
  }
  changeRadioEventHandler(checkedIndex:number,answer:number)
  {
    this.currentRadioSelected=checkedIndex;
    this.selectedAnswer=checkedIndex;
    if (this.currentRadioSelected === answer) {
      this.numberOfCorrectAns++;  
    }
    
    
  }
}
