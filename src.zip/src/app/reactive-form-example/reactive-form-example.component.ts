import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form-example',
  templateUrl: './reactive-form-example.component.html',
  styleUrls: ['./reactive-form-example.component.css']
})
export class ReactiveFormExampleComponent implements OnInit {
  loginForm=new FormGroup({
    userName:new FormControl("",Validators.required),
    password:new FormControl("",[Validators.required,Validators.minLength(8)]),
    email:new FormControl("",Validators.email),
    userId:new FormControl("",Validators.pattern(/^SL/)),
    phoneNumber:new FormControl("",[Validators.minLength(10),Validators.maxLength(10),Validators.pattern(/0-9/)])
  })
  constructor() { }

  ngOnInit(): void {
  }
submitEventHandler()
{

}
}
