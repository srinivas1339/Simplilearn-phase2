import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-finish',
  templateUrl: './finish.component.html',
  styleUrls: ['./finish.component.css']
})
export class FinishComponent implements OnInit {
score:string;
  constructor(public activatedRoute:ActivatedRoute,public router:Router) { }

  ngOnInit(): void {
    this.score=this.activatedRoute.snapshot.paramMap.get("totalScore");
  }

}
